from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Movie, models, ciniprofessional
from .serializers import ciniprofessional_serializers, ciniprofessional_serializers2



class movie_review(APIView):
    
    def get(self,request):
        all_movie_show= ciniprofessional.objects.all()
        # movie_list=[]
        # for all_movies in all_movie_show:
        #     # print(all_movies)
            
        #     singel_name={ 
        #         "id":all_movies.id,
        #         'name':all_movies.name,
        #         "profile":all_movies.profile,
        #         "date_of_birth":all_movies.data_of_birth
        #         }
            
        #     movie_list.append(singel_name)
        # # print
        # return Response(movie_list)
        serialized_products=ciniprofessional_serializers(all_movie_show,many =True).data
        print(serialized_products)
        return Response(serialized_products)
    
    def post(self,request):
        new_movies=ciniprofessional(name=request.data['name'],profile=request.data['profile'])
        new_movies.save()
        print(new_movies)
        # singel_name={ 
        #     "id":new_movies.id,
        #     'name':new_movies.name,
        #     "profile":new_movies.profile,
        #     "date_of_birth":new_movies.data_of_birth
        #     }
        # # print(singel_name)
        # return Response(singel_name)
        serializer_code=ciniprofessional_serializers2(new_movies).data
        print(serializer_code)
        return Response(serializer_code)
        # all_movie=ciniprofessional.objects.all()
        # for all_movies in all_movie:
        #     print(all_movies)
        
          
class movie_view_by_id(APIView):
    
    
    def get(self,request,id):
        
        movie_name_id=ciniprofessional.objects.get(id=id)
        print(movie_name_id)
        # singel_name={ 
        #     "id":movie_name_id.id,
        #     'name':movie_name_id.name,
        #     "profile":movie_name_id.profile,
        #     "date_of_birth":movie_name_id.data_of_birth
        #     }
        # # print(singel_name)
        # return Response(singel_name)
        serializer_code=ciniprofessional_serializers2(movie_name_id).data
        print(serializer_code)
        return Response(serializer_code)
            