from rest_framework import serializers
from .models import ciniprofessional




class ciniprofessional_serializers(serializers.ModelSerializer):
    class Meta:
        model= ciniprofessional
        fields= '__all__'
        
        
        
class ciniprofessional_serializers2(serializers.ModelSerializer):
    class Meta:
        model= ciniprofessional
        fields=['name',"profile","id"]