# from django.contrib import admin
# from Movie_app.models import ciniprofessional,Movie,movieReview



# admin.site.register(ciniprofessional)
# admin.site.register(Movie)
# admin.site.register(movieReview)
# # Register your models here.
