from django.db import models

# Create your models here.


class ciniprofessional(models.Model):
    """
    store information
    """
    name=models.CharField(max_length=300)
    profile= models.TextField()
    data_of_birth= models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name

class Movie(models.Model):
    """
    to store imformation in data base

    """
    title= models.CharField(max_length=200)
    plot=models.TextField()
    cast= models.ManyToManyField(ciniprofessional,related_name="movie_cast")
    producer= models.ForeignKey(ciniprofessional,related_name="movie_producer",on_delete= models.CASCADE)
    director= models.ForeignKey(ciniprofessional,related_name='movie_director',on_delete=models.CASCADE)
    
    
class movieReview(models.Model):
    movie= models.ForeignKey(Movie,related_name="movie_review",on_delete=models.CASCADE)
    review= models.TextField()