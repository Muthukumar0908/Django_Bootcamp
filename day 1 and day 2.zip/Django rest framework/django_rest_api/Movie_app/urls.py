from django.urls import path
from .views import movie_review,movie_view_by_id


urlpatterns = [
    path('add/',movie_review.as_view()),
    path("add/<int:id>/",movie_view_by_id.as_view())
] 